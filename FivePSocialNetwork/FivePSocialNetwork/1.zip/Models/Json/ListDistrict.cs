﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FivePSocialNetwork.Models.Json
{
    public class ListDistrict
    {
        public int district_id { get; set; }
        public string district_name { get; set; }
    }
}