﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FivePSocialNetwork.Models.Json
{
    public class IndexCemterStatistical
    {
        //thống kê
        public int totalQuestion { get; set; }
        public int totalAnswer { get; set; }
        public int totalTechnology { get; set; }
        public int totalPost { get; set; }
    }
}